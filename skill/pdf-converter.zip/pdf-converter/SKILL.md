---
name: pdf-converter
description: Converts PDF documents to editable DOCX format. Handles single files or batch directory processing using the pdf2docx library.
---

# PDF Converter Skill

This skill allows you to convert PDF files into editable Microsoft Word (.docx) documents. It supports both single file conversion and batch processing of entire directories.

## When to Use This Skill

Use this skill when the user wants to:
- Convert a specific PDF file to Word/DOCX.
- Convert all PDFs in a folder to DOCX.
- "Change this PDF to Word".
- "Make this PDF editable".

## Instructions

To convert PDFs, follow these steps:

### 1. Environment Check
First, verify that the required library `pdf2docx` is installed in the current environment.
```bash
python3 -c "import pdf2docx" 2>/dev/null || pip install pdf2docx
```

### 2. Locate the Script
The conversion logic is encapsulated in the bundled script `scripts/convert.py`.
Locate the absolute path of this script within the skill directory.
(Typical location: `~/.gemini/skills/pdf-converter/scripts/convert.py`)

### 3. Execute Conversion
Run the script using the Python interpreter, passing the target file or directory as an argument.

**For a single file:**
```bash
python3 <path_to_skill_script>/convert.py "/path/to/source.pdf"
```

**For a directory (Batch Mode):**
```bash
python3 <path_to_skill_script>/convert.py "/path/to/directory/"
```

### 4. Verify and Report
- The script will output the path of the generated `.docx` file(s).
- Confirm to the user that the conversion is complete and provide the location of the new file(s).
- If the conversion fails (e.g., due to scanned PDF limitations), inform the user that `pdf2docx` works best on native PDFs and scanned files may require OCR (which is not currently supported by this simple script).
